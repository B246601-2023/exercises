# This script is not going to work
# This script is not good
#This is my better script 
#Done using different approaches
